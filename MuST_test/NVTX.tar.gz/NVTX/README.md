1. Put new-nvhpc-gpu inside architecture
2. NvtxModule.F90 inside MST/lib/
3. Makefile inside MST/lib/
4. Other 2 .F90 files inside MST/src
5. make new-nvhpc-gpu suffix=try1

jobscript:

#!/bin/bash
#SBATCH --job-name=must-test      # Job name
#SBATCH -N 1 # Number of nodes
#SBATCH -p GPU-shared
#SBATCH --gpus=h100-80:2
#SBATCH -J h100test
#SBATCH --ntasks-per-node=16
#SBATCH -t 1:00:00             # Max time for the job
#SBATCH --mem=100G

# Set up the environment
#module load singularity
#cd $SLURM_SUBMIT_DIR

set -x

module use /opt/packages/nvhpc/v25.5/modulefiles/
module load nvhpc/25.5
#Provide your path to mst2
export PATH=/ocean/projects/pscstaff/nnepal/new_MusT/MuST/bin/try1:$PATH
mpirun -np 16 nsys profile -o output mst2 < i_mst

